import { Component, inject, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DesignerStateService } from '../../core/services/designer-state.service';
import { DragDropService } from '../../core/services/drag-drop.service';
import { CanvasElementComponent } from '../canvas-element/canvas-element';
import { createDefaultCanvasElement, MM_TO_PX, A4_WIDTH_MM, A4_HEIGHT_MM, DEFAULT_GRID_SIZE_MM } from '../../shared/models/schema';

@Component({
  selector: 'app-canvas',
  imports: [CommonModule, CanvasElementComponent],
  templateUrl: './canvas.html',
  styleUrl: './canvas.less',
  standalone: true
})
export class CanvasComponent {
  private designerState = inject(DesignerStateService);
  private dragDropService = inject(DragDropService);
  
  protected elements = this.designerState.elements;
  protected selectedElementId = this.designerState.selectedElementId;
  protected dragState = this.dragDropService.dragState;
  protected visualGridSize = this.designerState.visualGridSize;
  protected logicalGridSize = this.designerState.logicalGridSize;
  
  protected readonly MM_TO_PX = MM_TO_PX;
  protected readonly A4_WIDTH_MM = A4_WIDTH_MM;
  protected readonly A4_HEIGHT_MM = A4_HEIGHT_MM;

  @HostListener('mousemove', ['$event'])
  onMouseMove(event: MouseEvent) {
    const canvas = (event.currentTarget as HTMLElement).querySelector('.a4-sheet');
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    
    const xMm = this.dragDropService.pxToMm(x, MM_TO_PX);
    const yMm = this.dragDropService.pxToMm(y, MM_TO_PX);
    
    this.designerState.setCursorPosition(Math.round(xMm), Math.round(yMm));
    
    if (this.dragState().isDragging) {
      this.dragDropService.updateGhostPosition(event.clientX, event.clientY);
    }
  }

  onDrop(event: DragEvent) {
    event.preventDefault();
    const canvas = (event.currentTarget as HTMLElement).querySelector('.a4-sheet');
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    
    let xMm = this.dragDropService.pxToMm(x, MM_TO_PX);
    let yMm = this.dragDropService.pxToMm(y, MM_TO_PX);
    
    const draggedItem = this.dragState().draggedItem;
    if (draggedItem) {
      // Offset position to center the element under cursor
      const halfWidth = draggedItem.defaultWidth / 2;
      const halfHeight = draggedItem.defaultHeight / 2;
      
      xMm = xMm - halfWidth;
      yMm = yMm - halfHeight;
      
      // Snap to grid using logical grid size
      xMm = this.dragDropService.snapToGrid(xMm, this.logicalGridSize());
      yMm = this.dragDropService.snapToGrid(yMm, this.logicalGridSize());
      
      // Ensure within bounds
      xMm = Math.max(0, Math.min(xMm, A4_WIDTH_MM - draggedItem.defaultWidth));
      yMm = Math.max(0, Math.min(yMm, A4_HEIGHT_MM - draggedItem.defaultHeight));
      
      const newElement = createDefaultCanvasElement(draggedItem.type, xMm, yMm, draggedItem);
      this.designerState.addElement({
        ...newElement,
        id: `el-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
      });
    }
    
    this.dragDropService.endDrag();
  }

  onDragOver(event: DragEvent) {
    event.preventDefault();
    if (event.dataTransfer) {
      event.dataTransfer.dropEffect = 'copy';
    }
  }

  onCanvasClick() {
    this.designerState.selectElement(null);
  }
}
