import { Component, Input, Output, EventEmitter, inject, HostListener, HostBinding, ElementRef, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CanvasElement } from '../../shared/models/schema';
import { DesignerStateService } from '../../core/services/designer-state.service';

@Component({
  selector: 'app-canvas-element',
  imports: [CommonModule],
  templateUrl: './canvas-element.html',
  styleUrl: './canvas-element.less',
  standalone: true,
  host: {
    '[class.selected]': 'isSelected',
  }
})
export class CanvasElementComponent {
  @Input({ required: true }) element!: CanvasElement;
  @Input() isSelected: boolean = false;
  @Input() gridSize: number = 10;
  @Input() mmToPx: number = 3.7795275591;
  
  @HostBinding('style.left') get left() { return `${this.element.x}mm`; }
  @HostBinding('style.top') get top() { return `${this.element.y}mm`; }
  @HostBinding('style.width') get width() { return `${this.element.width}mm`; }
  @HostBinding('style.height') get height() { return `${this.element.height}mm`; }
  
  private elementRef = inject(ElementRef);
  private designerState = inject(DesignerStateService);
  
  protected showContextMenu = signal(false);
  protected contextMenuPosition = signal({ x: 0, y: 0 });
  
  private isDragging = false;
  private dragStart = { x: 0, y: 0 };

  onClick(event: MouseEvent) {
    event.stopPropagation();
    this.designerState.selectElement(this.element.id);
  }

  onMouseDown(event: MouseEvent) {
    if (event.button !== 0) return;
    event.stopPropagation();
    
    this.designerState.selectElement(this.element.id);
    this.isDragging = true;
    
    const rect = this.elementRef.nativeElement.getBoundingClientRect();
    this.dragStart = {
      x: event.clientX - rect.left,
      y: event.clientY - rect.top,
    };
  }

  @HostListener('document:mousemove', ['$event'])
  onMouseMove(event: MouseEvent) {
    if (!this.isDragging) return;
    
    const parent = this.elementRef.nativeElement.parentElement;
    if (!parent) return;
    
    const canvasRect = parent.getBoundingClientRect();
    const pxX = event.clientX - canvasRect.left - this.dragStart.x;
    const pxY = event.clientY - canvasRect.top - this.dragStart.y;
    
    const mmX = pxX / this.mmToPx;
    const mmY = pxY / this.mmToPx;
    
    const newX = this.snapToGrid(mmX);
    const newY = this.snapToGrid(mmY);

    this.designerState.updateElement(this.element.id, {
      x: Math.max(0, newX),
      y: Math.max(0, newY),
    });
  }

  @HostListener('document:mouseup')
  onMouseUp() {
    this.isDragging = false;
  }

  onContextMenu(event: MouseEvent) {
    event.preventDefault();
    event.stopPropagation();
    this.contextMenuPosition.set({ x: event.clientX, y: event.clientY });
    this.showContextMenu.set(true);
  }

  closeContextMenu() {
    this.showContextMenu.set(false);
  }

  onDelete() {
    this.designerState.removeElement(this.element.id);
    this.closeContextMenu();
  }

  onProperties() {
    this.designerState.selectElement(this.element.id);
    this.closeContextMenu();
  }

  private snapToGrid(value: number): number {
    return Math.round(value / this.gridSize) * this.gridSize;
  }
}
