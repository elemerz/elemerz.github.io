import { Component } from '@angular/core';

@Component({
  selector: 'app-open-dialog',
  imports: [],
  templateUrl: './open-dialog.html',
  styleUrl: './open-dialog.less'
})
export class OpenDialog {

}
