import { Component } from '@angular/core';

@Component({
  selector: 'app-save-dialog',
  imports: [],
  templateUrl: './save-dialog.html',
  styleUrl: './save-dialog.less'
})
export class SaveDialog {

}
