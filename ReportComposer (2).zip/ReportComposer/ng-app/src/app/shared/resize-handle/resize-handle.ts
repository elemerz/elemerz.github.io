import { Component } from '@angular/core';

@Component({
  selector: 'app-resize-handle',
  imports: [],
  templateUrl: './resize-handle.html',
  styleUrl: './resize-handle.less'
})
export class ResizeHandle {

}
