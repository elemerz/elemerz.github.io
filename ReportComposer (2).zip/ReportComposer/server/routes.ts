import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertReportLayoutSchema, reportLayoutSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/layouts", async (req, res) => {
    try {
      const layouts = await storage.getAllLayouts();
      res.json(layouts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch layouts" });
    }
  });

  app.get("/api/layouts/:id", async (req, res) => {
    try {
      const layout = await storage.getLayout(req.params.id);
      if (!layout) {
        return res.status(404).json({ error: "Layout not found" });
      }
      res.json(layout);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch layout" });
    }
  });

  app.post("/api/layouts", async (req, res) => {
    try {
      const validatedData = insertReportLayoutSchema.parse(req.body);
      const layout = await storage.createLayout(validatedData);
      res.status(201).json(layout);
    } catch (error) {
      res.status(400).json({ error: "Invalid layout data" });
    }
  });

  app.patch("/api/layouts/:id", async (req, res) => {
    try {
      const updates = req.body;
      const layout = await storage.updateLayout(req.params.id, updates);
      if (!layout) {
        return res.status(404).json({ error: "Layout not found" });
      }
      res.json(layout);
    } catch (error) {
      res.status(400).json({ error: "Invalid update data" });
    }
  });

  app.delete("/api/layouts/:id", async (req, res) => {
    try {
      const success = await storage.deleteLayout(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Layout not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete layout" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
