import { type User, type InsertUser, type ReportLayout, type InsertReportLayout } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getLayout(id: string): Promise<ReportLayout | undefined>;
  getAllLayouts(): Promise<ReportLayout[]>;
  createLayout(layout: InsertReportLayout): Promise<ReportLayout>;
  updateLayout(id: string, layout: Partial<ReportLayout>): Promise<ReportLayout | undefined>;
  deleteLayout(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private layouts: Map<string, ReportLayout>;

  constructor() {
    this.users = new Map();
    this.layouts = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getLayout(id: string): Promise<ReportLayout | undefined> {
    return this.layouts.get(id);
  }

  async getAllLayouts(): Promise<ReportLayout[]> {
    return Array.from(this.layouts.values());
  }

  async createLayout(insertLayout: InsertReportLayout): Promise<ReportLayout> {
    const id = randomUUID();
    const layout: ReportLayout = { ...insertLayout, id };
    this.layouts.set(id, layout);
    return layout;
  }

  async updateLayout(id: string, updates: Partial<ReportLayout>): Promise<ReportLayout | undefined> {
    const existing = this.layouts.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.layouts.set(id, updated);
    return updated;
  }

  async deleteLayout(id: string): Promise<boolean> {
    return this.layouts.delete(id);
  }
}

export const storage = new MemStorage();
