#!/bin/bash

# Start Express backend on port 3000
PORT=3000 NODE_ENV=development tsx server/index.ts &
BACKEND_PID=$!

# Wait for backend to start
sleep 2

# Start Angular frontend on port 4200 (with proxy to backend)
# DANGEROUSLY_DISABLE_HOST_CHECK allows Replit's dynamic URLs
cd ng-app && DANGEROUSLY_DISABLE_HOST_CHECK=true npm start

# Cleanup: Kill backend when Angular exits
kill $BACKEND_PID
