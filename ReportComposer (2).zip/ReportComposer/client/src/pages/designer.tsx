import { useState, useRef, useCallback, useEffect } from "react";
import { CanvasElement, toolbarElements } from "@shared/schema";
import { MenuBar } from "@/components/designer/MenuBar";
import { ToolbarPanel } from "@/components/designer/ToolbarPanel";
import { Canvas } from "@/components/designer/Canvas";
import { StatusBar } from "@/components/designer/StatusBar";
import { PropertyPanel } from "@/components/designer/PropertyPanel";
import { ResizeHandle } from "@/components/designer/ResizeHandle";
import { SaveDialog } from "@/components/designer/SaveDialog";
import { OpenDialog } from "@/components/designer/OpenDialog";
import { useCreateLayout, useUpdateLayout } from "@/hooks/useLayouts";
import { useToast } from "@/hooks/use-toast";

export default function Designer() {
  const [elements, setElements] = useState<CanvasElement[]>([]);
  const [selectedElement, setSelectedElement] = useState<CanvasElement | null>(null);
  const [statusMessage, setStatusMessage] = useState("Ready");
  const [cursorPosition, setCursorPosition] = useState({ x: 0, y: 0 });
  const [currentLayoutId, setCurrentLayoutId] = useState<string | null>(null);
  const [currentLayoutName, setCurrentLayoutName] = useState("Untitled Layout");
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [showOpenDialog, setShowOpenDialog] = useState(false);
  
  const [westWidth, setWestWidth] = useState(256);
  const [eastWidth, setEastWidth] = useState(320);
  const [westCollapsed, setWestCollapsed] = useState(false);
  const [eastCollapsed, setEastCollapsed] = useState(false);
  
  const [history, setHistory] = useState<CanvasElement[][]>([[]]);
  const [historyIndex, setHistoryIndex] = useState(0);
  
  const gridSize = 10;
  const { toast } = useToast();
  const createLayout = useCreateLayout();
  const updateLayout = useUpdateLayout();

  useEffect(() => {
    setHistory([elements]);
    setHistoryIndex(0);
  }, []);

  const addToHistory = useCallback((newElements: CanvasElement[]) => {
    setHistory(prev => {
      const newHistory = prev.slice(0, historyIndex + 1);
      newHistory.push(newElements);
      return newHistory;
    });
    setHistoryIndex(prev => prev + 1);
  }, [historyIndex]);

  const handleElementDrop = useCallback((element: CanvasElement) => {
    setElements(prev => {
      const newElements = [...prev, element];
      addToHistory(newElements);
      return newElements;
    });
    setStatusMessage(`Added ${element.type} element`);
  }, [addToHistory]);

  const handleElementSelect = useCallback((element: CanvasElement | null) => {
    setSelectedElement(element);
    if (element) {
      setStatusMessage(`Selected ${element.type} element`);
    } else {
      setStatusMessage("Ready");
    }
  }, []);

  const handleElementUpdate = useCallback((updatedElement: CanvasElement) => {
    setElements(prev => {
      const newElements = prev.map(el => el.id === updatedElement.id ? updatedElement : el);
      addToHistory(newElements);
      return newElements;
    });
    setSelectedElement(updatedElement);
  }, [addToHistory]);

  const handleElementDelete = useCallback((elementId: string) => {
    setElements(prev => {
      const newElements = prev.filter(el => el.id !== elementId);
      addToHistory(newElements);
      return newElements;
    });
    setSelectedElement(null);
    setStatusMessage("Element deleted");
  }, [addToHistory]);

  const handleNew = () => {
    setElements([]);
    setSelectedElement(null);
    setCurrentLayoutId(null);
    setCurrentLayoutName("Untitled Layout");
    setHistory([[]]);
    setHistoryIndex(0);
    setStatusMessage("New layout created");
  };

  const handleSave = () => {
    if (currentLayoutId) {
      updateLayout.mutate({
        id: currentLayoutId,
        updates: { elements, name: currentLayoutName }
      }, {
        onSuccess: () => {
          toast({ title: "Layout saved successfully" });
          setStatusMessage("Layout saved");
        },
        onError: () => {
          toast({ title: "Failed to save layout", variant: "destructive" });
        }
      });
    } else {
      setShowSaveDialog(true);
    }
  };

  const handleSaveAs = (name: string) => {
    createLayout.mutate({
      name,
      elements,
      gridSize,
      canvasWidth: 297,
      canvasHeight: 210,
    }, {
      onSuccess: (data: any) => {
        setCurrentLayoutId(data.id);
        setCurrentLayoutName(name);
        toast({ title: "Layout saved successfully" });
        setStatusMessage("Layout saved");
        setShowSaveDialog(false);
      },
      onError: () => {
        toast({ title: "Failed to save layout", variant: "destructive" });
      }
    });
  };

  const handleOpen = () => {
    setShowOpenDialog(true);
  };

  const handleLoadLayout = (layout: { id: string; name: string; elements: CanvasElement[] }) => {
    setElements(layout.elements);
    setCurrentLayoutId(layout.id);
    setCurrentLayoutName(layout.name);
    setHistory([layout.elements]);
    setHistoryIndex(0);
    setSelectedElement(null);
    setShowOpenDialog(false);
    setStatusMessage(`Opened ${layout.name}`);
  };

  const handleClose = () => {
    handleNew();
  };

  const handleUndo = () => {
    if (historyIndex > 0) {
      setHistoryIndex(prev => prev - 1);
      setElements(history[historyIndex - 1]);
      setStatusMessage("Undo");
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(prev => prev + 1);
      setElements(history[historyIndex + 1]);
      setStatusMessage("Redo");
    }
  };

  const handleOptions = () => {
    setStatusMessage("Options");
  };

  return (
    <div className="h-screen w-screen flex flex-col bg-background overflow-hidden">
      <MenuBar
        onNew={handleNew}
        onOpen={handleOpen}
        onSave={handleSave}
        onClose={handleClose}
        onUndo={handleUndo}
        onRedo={handleRedo}
        onOptions={handleOptions}
      />

      <div className="flex-1 flex overflow-hidden relative">
        {!westCollapsed && (
          <>
            <div 
              className="bg-sidebar border-r border-sidebar-border overflow-hidden transition-all duration-300"
              style={{ width: westWidth }}
            >
              <ToolbarPanel 
                elements={toolbarElements}
                onStatusMessage={setStatusMessage}
              />
            </div>
            <ResizeHandle
              direction="vertical"
              onResize={(delta: number) => setWestWidth(prev => Math.max(200, Math.min(400, prev + delta)))}
            />
          </>
        )}

        <div className="flex-1 flex flex-col overflow-hidden bg-accent/20">
          <Canvas
            elements={elements}
            selectedElement={selectedElement}
            gridSize={gridSize}
            onElementDrop={handleElementDrop}
            onElementSelect={handleElementSelect}
            onElementUpdate={handleElementUpdate}
            onElementDelete={handleElementDelete}
            onCursorMove={setCursorPosition}
            onStatusMessage={setStatusMessage}
          />
        </div>

        {!eastCollapsed && (
          <>
            <ResizeHandle
              direction="vertical"
              onResize={(delta: number) => setEastWidth(prev => Math.max(280, Math.min(500, prev - delta)))}
            />
            <div 
              className="bg-sidebar border-l border-sidebar-border overflow-hidden transition-all duration-300"
              style={{ width: eastWidth }}
            >
              <PropertyPanel
                element={selectedElement}
                onUpdate={handleElementUpdate}
                onClearSelection={() => setSelectedElement(null)}
              />
            </div>
          </>
        )}

        <button
          onClick={() => setWestCollapsed(!westCollapsed)}
          className="absolute top-1/2 -translate-y-1/2 w-6 h-20 bg-primary/90 hover:bg-primary border-2 border-primary shadow-lg rounded-r-lg flex items-center justify-center z-10 transition-all duration-300"
          style={{ left: westCollapsed ? 0 : westWidth }}
          data-testid="button-toggle-west"
        >
          <span className="text-primary-foreground text-sm font-bold">
            {westCollapsed ? "›" : "‹"}
          </span>
        </button>

        <button
          onClick={() => setEastCollapsed(!eastCollapsed)}
          className="absolute top-1/2 -translate-y-1/2 w-6 h-20 bg-primary/90 hover:bg-primary border-2 border-primary shadow-lg rounded-l-lg flex items-center justify-center z-10 transition-all duration-300"
          style={{ right: eastCollapsed ? 0 : eastWidth }}
          data-testid="button-toggle-east"
        >
          <span className="text-primary-foreground text-sm font-bold">
            {eastCollapsed ? "‹" : "›"}
          </span>
        </button>
      </div>

      <StatusBar 
        message={statusMessage} 
        cursorPosition={cursorPosition}
      />

      <SaveDialog
        open={showSaveDialog}
        onOpenChange={setShowSaveDialog}
        onSave={handleSaveAs}
        isSaving={createLayout.isPending}
      />

      <OpenDialog
        open={showOpenDialog}
        onOpenChange={setShowOpenDialog}
        onLoad={handleLoadLayout}
      />
    </div>
  );
}
