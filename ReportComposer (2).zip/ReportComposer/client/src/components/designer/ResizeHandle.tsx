import { useRef, useState, useEffect, useCallback } from "react";

interface ResizeHandleProps {
  direction: "vertical" | "horizontal";
  onResize: (delta: number) => void;
}

export function ResizeHandle({ direction, onResize }: ResizeHandleProps) {
  const [isDragging, setIsDragging] = useState(false);
  const startPosRef = useRef(0);

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    startPosRef.current = direction === "vertical" ? e.clientX : e.clientY;
    e.preventDefault();
  };

  const handleMouseMove = useCallback((e: MouseEvent) => {
    const currentPos = direction === "vertical" ? e.clientX : e.clientY;
    const delta = currentPos - startPosRef.current;
    startPosRef.current = currentPos;
    onResize(delta);
  }, [direction, onResize]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  useEffect(() => {
    if (isDragging) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
      return () => {
        document.removeEventListener("mousemove", handleMouseMove);
        document.removeEventListener("mouseup", handleMouseUp);
      };
    }
  }, [isDragging, handleMouseMove, handleMouseUp]);

  return (
    <div
      className={`
        ${direction === "vertical" ? "w-1 h-full cursor-col-resize" : "h-1 w-full cursor-row-resize"}
        ${isDragging ? "bg-primary" : "bg-border hover:bg-primary/50"}
        transition-colors relative group
      `}
      onMouseDown={handleMouseDown}
      data-testid={`resize-handle-${direction}`}
    >
      <div 
        className={`
          absolute 
          ${direction === "vertical" ? "left-[-3px] top-0 w-[7px] h-full" : "top-[-3px] left-0 h-[7px] w-full"}
        `}
      />
    </div>
  );
}
