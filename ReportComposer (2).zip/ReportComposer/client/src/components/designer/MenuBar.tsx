import { useState } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";

interface MenuBarProps {
  onNew: () => void;
  onOpen: () => void;
  onSave: () => void;
  onClose: () => void;
  onUndo: () => void;
  onRedo: () => void;
  onOptions: () => void;
}

export function MenuBar({ 
  onNew, 
  onOpen, 
  onSave, 
  onClose, 
  onUndo, 
  onRedo, 
  onOptions 
}: MenuBarProps) {
  const [openMenu, setOpenMenu] = useState<string | null>(null);

  return (
    <div className="h-10 bg-sidebar border-b border-sidebar-border flex items-center px-2 gap-1" data-testid="menubar">
      <DropdownMenu open={openMenu === 'file'} onOpenChange={(open) => setOpenMenu(open ? 'file' : null)}>
        <DropdownMenuTrigger asChild>
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-sm font-medium h-8"
            data-testid="menu-file"
          >
            File
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-48">
          <DropdownMenuItem onClick={onNew} data-testid="menu-file-new">
            New
            <span className="ml-auto text-xs text-muted-foreground">Ctrl+N</span>
          </DropdownMenuItem>
          <DropdownMenuItem onClick={onOpen} data-testid="menu-file-open">
            Open
            <span className="ml-auto text-xs text-muted-foreground">Ctrl+O</span>
          </DropdownMenuItem>
          <DropdownMenuItem onClick={onSave} data-testid="menu-file-save">
            Save
            <span className="ml-auto text-xs text-muted-foreground">Ctrl+S</span>
          </DropdownMenuItem>
          <DropdownMenuItem onClick={onClose} data-testid="menu-file-close">
            Close
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <DropdownMenu open={openMenu === 'edit'} onOpenChange={(open) => setOpenMenu(open ? 'edit' : null)}>
        <DropdownMenuTrigger asChild>
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-sm font-medium h-8"
            data-testid="menu-edit"
          >
            Edit
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-48">
          <DropdownMenuItem onClick={onUndo} data-testid="menu-edit-undo">
            Undo
            <span className="ml-auto text-xs text-muted-foreground">Ctrl+Z</span>
          </DropdownMenuItem>
          <DropdownMenuItem onClick={onRedo} data-testid="menu-edit-redo">
            Redo
            <span className="ml-auto text-xs text-muted-foreground">Ctrl+Y</span>
          </DropdownMenuItem>
          <DropdownMenuItem onClick={onOptions} data-testid="menu-edit-options">
            Options
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
