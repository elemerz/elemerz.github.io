import { ToolbarElement } from "@shared/schema";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { ToolbarItem } from "./ToolbarItem";

interface ToolbarPanelProps {
  elements: ToolbarElement[];
  onStatusMessage: (message: string) => void;
}

export function ToolbarPanel({ elements, onStatusMessage }: ToolbarPanelProps) {
  const categories = {
    text: { label: "Text Elements", items: elements.filter(e => e.category === "text") },
    containers: { label: "Containers", items: elements.filter(e => e.category === "containers") },
    form: { label: "Form Elements", items: elements.filter(e => e.category === "form") },
    media: { label: "Media", items: elements.filter(e => e.category === "media") },
    layout: { label: "Layout", items: elements.filter(e => e.category === "layout") },
  };

  return (
    <div className="h-full overflow-y-auto p-4" data-testid="toolbar-panel">
      <h2 className="text-sm font-semibold mb-4 text-sidebar-foreground">Toolbox</h2>
      <Accordion type="multiple" defaultValue={["text", "containers", "form"]} className="space-y-2">
        {Object.entries(categories).map(([key, { label, items }]) => (
          <AccordionItem key={key} value={key} className="border-sidebar-border">
            <AccordionTrigger 
              className="text-sm font-medium hover:no-underline py-3 px-4 rounded-md hover-elevate"
              data-testid={`accordion-${key}`}
            >
              {label}
            </AccordionTrigger>
            <AccordionContent className="pt-2 pb-4">
              <div className="grid grid-cols-2 gap-2 px-2">
                {items.map((item) => (
                  <ToolbarItem
                    key={item.type}
                    element={item}
                    onDragStart={() => onStatusMessage(`Dragging ${item.label}`)}
                  />
                ))}
              </div>
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  );
}
