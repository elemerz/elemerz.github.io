interface StatusBarProps {
  message: string;
  cursorPosition: { x: number; y: number };
}

export function StatusBar({ message, cursorPosition }: StatusBarProps) {
  return (
    <div 
      className="h-8 bg-sidebar border-t border-sidebar-border flex items-center justify-between px-4 text-xs text-sidebar-foreground"
      data-testid="statusbar"
    >
      <span data-testid="status-message">{message}</span>
      <span className="font-mono text-muted-foreground" data-testid="status-coordinates">
        {cursorPosition.x}mm × {cursorPosition.y}mm
      </span>
    </div>
  );
}
