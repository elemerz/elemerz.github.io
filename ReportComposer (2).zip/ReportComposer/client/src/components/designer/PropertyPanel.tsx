import { CanvasElement } from "@shared/schema";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Settings } from "lucide-react";

interface PropertyPanelProps {
  element: CanvasElement | null;
  onUpdate: (element: CanvasElement) => void;
  onClearSelection: () => void;
}

export function PropertyPanel({ element, onUpdate, onClearSelection }: PropertyPanelProps) {
  const handlePropertyChange = (field: keyof CanvasElement, value: any) => {
    if (element) {
      onUpdate({ ...element, [field]: value });
    }
  };

  return (
    <div className="h-full flex flex-col bg-sidebar" data-testid="property-panel">
      <div className="flex items-center justify-between p-4 border-b border-sidebar-border">
        <h3 className="font-semibold text-sidebar-foreground">Properties</h3>
        <Settings className="w-4 h-4 text-muted-foreground" />
      </div>

      {!element ? (
        <div className="flex-1 flex items-center justify-center p-4">
          <div className="text-center text-muted-foreground">
            <Settings className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">No element selected</p>
            <p className="text-xs mt-1">Select an element to view its properties</p>
          </div>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto p-4 space-y-6">
          <div className="space-y-3">
            <h4 className="text-sm font-semibold text-sidebar-foreground">Element Info</h4>
            <div className="space-y-2">
              <div>
                <Label className="text-xs text-muted-foreground">Type</Label>
                <div className="text-sm font-mono mt-1 px-3 py-2 bg-muted rounded-md">
                  {element.type}
                </div>
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">ID</Label>
                <div className="text-sm font-mono mt-1 px-3 py-2 bg-muted rounded-md truncate">
                  {element.id}
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="text-sm font-semibold text-sidebar-foreground">Position</h4>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="pos-x" className="text-xs">X (mm)</Label>
                <Input
                  id="pos-x"
                  type="number"
                  value={element.x}
                  onChange={(e) => handlePropertyChange('x', parseFloat(e.target.value) || 0)}
                  className="mt-1"
                  data-testid="input-position-x"
                />
              </div>
              <div>
                <Label htmlFor="pos-y" className="text-xs">Y (mm)</Label>
                <Input
                  id="pos-y"
                  type="number"
                  value={element.y}
                  onChange={(e) => handlePropertyChange('y', parseFloat(e.target.value) || 0)}
                  className="mt-1"
                  data-testid="input-position-y"
                />
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="text-sm font-semibold text-sidebar-foreground">Size</h4>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="width" className="text-xs">Width (mm)</Label>
                <Input
                  id="width"
                  type="number"
                  value={element.width}
                  onChange={(e) => handlePropertyChange('width', parseFloat(e.target.value) || 10)}
                  className="mt-1"
                  data-testid="input-width"
                />
              </div>
              <div>
                <Label htmlFor="height" className="text-xs">Height (mm)</Label>
                <Input
                  id="height"
                  type="number"
                  value={element.height}
                  onChange={(e) => handlePropertyChange('height', parseFloat(e.target.value) || 10)}
                  className="mt-1"
                  data-testid="input-height"
                />
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="text-sm font-semibold text-sidebar-foreground">Content</h4>
            <div>
              <Label htmlFor="content" className="text-xs">Text Content</Label>
              <Textarea
                id="content"
                value={element.content}
                onChange={(e) => handlePropertyChange('content', e.target.value)}
                className="mt-1 min-h-[100px]"
                placeholder="Enter element content..."
                data-testid="input-content"
              />
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="text-sm font-semibold text-sidebar-foreground">Custom Properties</h4>
            <div className="text-xs text-muted-foreground p-3 bg-muted rounded-md">
              Additional properties can be added here
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
