import { useRef, useState, useEffect, useCallback } from "react";
import { CanvasElement } from "@shared/schema";
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuTrigger,
} from "@/components/ui/context-menu";

interface CanvasElementComponentProps {
  element: CanvasElement;
  isSelected: boolean;
  gridSize: number;
  onSelect: (element: CanvasElement) => void;
  onUpdate: (element: CanvasElement) => void;
  onDelete: (elementId: string) => void;
}

export function CanvasElementComponent({
  element,
  isSelected,
  gridSize,
  onSelect,
  onUpdate,
  onDelete,
}: CanvasElementComponentProps) {
  const elementRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef({ x: 0, y: 0 });

  // Conversion factor: 1mm = 3.7795275591 pixels at 96 DPI (CSS standard)
  const MM_TO_PX = 3.7795275591;
  
  const snapToGrid = (value: number) => Math.round(value / gridSize) * gridSize;

  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button !== 0) return;
    e.stopPropagation();
    
    onSelect(element);
    setIsDragging(true);
    
    if (!elementRef.current) return;
    const rect = elementRef.current.getBoundingClientRect();
    dragStartRef.current = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };
  };

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!elementRef.current?.parentElement) return;
    
    const canvasRect = elementRef.current.parentElement.getBoundingClientRect();
    const pxX = e.clientX - canvasRect.left - dragStartRef.current.x;
    const pxY = e.clientY - canvasRect.top - dragStartRef.current.y;
    
    // Convert pixels to millimeters
    const mmX = pxX / MM_TO_PX;
    const mmY = pxY / MM_TO_PX;
    
    const newX = snapToGrid(mmX);
    const newY = snapToGrid(mmY);

    onUpdate({
      ...element,
      x: Math.max(0, newX),
      y: Math.max(0, newY),
    });
  }, [element, gridSize, onUpdate, snapToGrid, MM_TO_PX]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  useEffect(() => {
    if (isDragging) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
      return () => {
        document.removeEventListener("mousemove", handleMouseMove);
        document.removeEventListener("mouseup", handleMouseUp);
      };
    }
  }, [isDragging, handleMouseMove, handleMouseUp]);

  const getElementDisplay = () => {
    switch (element.type) {
      case "heading":
        return <div className="font-semibold text-lg">{element.content}</div>;
      case "paragraph":
        return <div className="text-sm">{element.content}</div>;
      case "text":
        return <div className="text-sm">{element.content}</div>;
      case "button":
        return <button className="px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm">{element.content}</button>;
      case "input":
        return <input type="text" placeholder={element.content} className="w-full px-3 py-1.5 border rounded-md text-sm" />;
      case "textarea":
        return <textarea placeholder={element.content} className="w-full h-full px-3 py-1.5 border rounded-md text-sm resize-none" />;
      case "checkbox":
        return (
          <div className="flex items-center gap-2">
            <input type="checkbox" className="w-4 h-4" />
            <span className="text-sm">{element.content}</span>
          </div>
        );
      case "radio":
        return (
          <div className="flex items-center gap-2">
            <input type="radio" className="w-4 h-4" />
            <span className="text-sm">{element.content}</span>
          </div>
        );
      case "select":
        return (
          <select className="w-full px-3 py-1.5 border rounded-md text-sm">
            <option>{element.content}</option>
          </select>
        );
      case "div":
      case "section":
      case "article":
        return <div className="w-full h-full border-2 border-dashed border-muted-foreground/30 rounded flex items-center justify-center text-xs text-muted-foreground">{element.type}</div>;
      case "image":
        return <div className="w-full h-full bg-muted border border-border rounded flex items-center justify-center text-xs text-muted-foreground">Image</div>;
      case "video":
        return <div className="w-full h-full bg-muted border border-border rounded flex items-center justify-center text-xs text-muted-foreground">Video</div>;
      case "audio":
        return <div className="w-full h-full bg-muted border border-border rounded flex items-center justify-center text-xs text-muted-foreground">Audio</div>;
      case "table":
        return (
          <table className="w-full h-full border-collapse text-xs">
            <thead>
              <tr>
                <th className="border border-border p-1">Header 1</th>
                <th className="border border-border p-1">Header 2</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border border-border p-1">Cell 1</td>
                <td className="border border-border p-1">Cell 2</td>
              </tr>
            </tbody>
          </table>
        );
      case "list":
        return (
          <ul className="list-disc list-inside text-sm">
            <li>Item 1</li>
            <li>Item 2</li>
            <li>Item 3</li>
          </ul>
        );
      case "link":
        return <a href="#" className="text-primary underline text-sm">{element.content}</a>;
      default:
        return <div className="text-sm">{element.content}</div>;
    }
  };

  return (
    <ContextMenu>
      <ContextMenuTrigger>
        <div
          ref={elementRef}
          className={`absolute cursor-move select-none transition-shadow ${
            isSelected 
              ? 'ring-2 ring-primary shadow-lg' 
              : 'ring-1 ring-primary/40 hover:ring-primary/80'
          } ${isDragging ? 'cursor-grabbing opacity-75' : ''}`}
          style={{
            left: `${element.x}mm`,
            top: `${element.y}mm`,
            width: `${element.width}mm`,
            height: `${element.height}mm`,
          }}
          onMouseDown={handleMouseDown}
          data-testid={`canvas-element-${element.id}`}
        >
          <div className="w-full h-full p-2 bg-background/95 rounded-sm overflow-hidden">
            {getElementDisplay()}
          </div>
          
          {isSelected && (
            <>
              <div className="absolute -top-6 left-0 bg-primary text-primary-foreground px-2 py-0.5 rounded-t text-xs font-mono">
                {element.x}mm × {element.y}mm
              </div>
              <div className="absolute -bottom-6 right-0 bg-primary text-primary-foreground px-2 py-0.5 rounded-b text-xs font-mono">
                {element.width}mm × {element.height}mm
              </div>
            </>
          )}
        </div>
      </ContextMenuTrigger>
      <ContextMenuContent className="w-48">
        <ContextMenuItem onClick={() => onSelect(element)} data-testid={`context-properties-${element.id}`}>
          Properties
        </ContextMenuItem>
        <ContextMenuItem 
          onClick={() => onDelete(element.id)} 
          className="text-destructive"
          data-testid={`context-delete-${element.id}`}
        >
          Delete
        </ContextMenuItem>
      </ContextMenuContent>
    </ContextMenu>
  );
}
