import { useRef, useState, useCallback } from "react";
import { CanvasElement, ToolbarElement } from "@shared/schema";
import { CanvasElementComponent } from "./CanvasElementComponent";

interface CanvasProps {
  elements: CanvasElement[];
  selectedElement: CanvasElement | null;
  gridSize: number;
  onElementDrop: (element: CanvasElement) => void;
  onElementSelect: (element: CanvasElement | null) => void;
  onElementUpdate: (element: CanvasElement) => void;
  onElementDelete: (elementId: string) => void;
  onCursorMove: (position: { x: number, y: number }) => void;
  onStatusMessage: (message: string) => void;
}

export function Canvas({
  elements,
  selectedElement,
  gridSize,
  onElementDrop,
  onElementSelect,
  onElementUpdate,
  onElementDelete,
  onCursorMove,
  onStatusMessage,
}: CanvasProps) {
  const canvasRef = useRef<HTMLDivElement>(null);
  const [isDraggingOver, setIsDraggingOver] = useState(false);
  const [dragPosition, setDragPosition] = useState<{ x: number, y: number } | null>(null);
  const [ghostElement, setGhostElement] = useState<ToolbarElement | null>(null);

  // Conversion factor: 1mm = 3.7795275591 pixels at 96 DPI (CSS standard)
  const MM_TO_PX = 3.7795275591;
  
  const snapToGrid = (value: number) => Math.round(value / gridSize) * gridSize;

  const getCanvasPosition = (clientX: number, clientY: number) => {
    if (!canvasRef.current) return { x: 0, y: 0 };
    const rect = canvasRef.current.getBoundingClientRect();
    // Get pixel position relative to canvas
    const pxX = clientX - rect.left;
    const pxY = clientY - rect.top;
    // Convert pixels to millimeters for consistent positioning
    const mmX = pxX / MM_TO_PX;
    const mmY = pxY / MM_TO_PX;
    return { x: snapToGrid(mmX), y: snapToGrid(mmY) };
  };

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "copy";
    
    const pos = getCanvasPosition(e.clientX, e.clientY);
    setDragPosition(pos);
    onCursorMove(pos);
  }, [gridSize, onCursorMove]);

  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(true);
    
    try {
      const data = e.dataTransfer.getData("application/json");
      if (data) {
        const element = JSON.parse(data) as ToolbarElement;
        setGhostElement(element);
      }
    } catch (err) {
      console.error("Failed to parse drag data", err);
    }
  };

  const handleDragLeave = (e: React.DragEvent) => {
    if (e.currentTarget === e.target) {
      setIsDraggingOver(false);
      setDragPosition(null);
      setGhostElement(null);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(false);
    setDragPosition(null);
    setGhostElement(null);

    try {
      const data = e.dataTransfer.getData("application/json");
      if (!data) return;

      const toolbarElement = JSON.parse(data) as ToolbarElement;
      const pos = getCanvasPosition(e.clientX, e.clientY);

      const newElement: CanvasElement = {
        id: `element-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        type: toolbarElement.type,
        x: pos.x,
        y: pos.y,
        width: toolbarElement.defaultWidth,
        height: toolbarElement.defaultHeight,
        properties: {},
        content: toolbarElement.label,
      };

      onElementDrop(newElement);
    } catch (err) {
      console.error("Failed to handle drop", err);
    }
  };

  const handleCanvasClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onElementSelect(null);
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    const pos = getCanvasPosition(e.clientX, e.clientY);
    onCursorMove(pos);
  };

  // A4 dimensions: 210mm x 297mm
  const A4_WIDTH = 210;
  const A4_HEIGHT = 297;

  const gridPattern = `
    <svg width="${A4_WIDTH}" height="${A4_HEIGHT}" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <pattern id="grid" width="${gridSize}" height="${gridSize}" patternUnits="userSpaceOnUse">
          <path d="M ${gridSize} 0 L 0 0 0 ${gridSize}" fill="none" stroke="currentColor" stroke-width="0.5" opacity="0.6"/>
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#grid)" />
    </svg>
  `;

  return (
    <div
      className="relative flex-1 overflow-auto bg-muted/30"
      data-testid="canvas-viewport"
    >
      <div className="min-h-full flex items-center justify-center p-8">
        <div
          ref={canvasRef}
          className={`relative bg-background shadow-2xl ${isDraggingOver ? 'ring-2 ring-primary' : 'ring-1 ring-border'}`}
          style={{
            width: `${A4_WIDTH}mm`,
            height: `${A4_HEIGHT}mm`,
          }}
          onDragOver={handleDragOver}
          onDragEnter={handleDragEnter}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={handleCanvasClick}
          onMouseMove={handleMouseMove}
          data-testid="canvas"
        >
          <div 
            className="absolute inset-0 text-muted-foreground/40 pointer-events-none"
            dangerouslySetInnerHTML={{ __html: gridPattern }}
          />
          
          <div className="relative w-full h-full">
            {elements.map((element) => (
              <CanvasElementComponent
                key={element.id}
                element={element}
                isSelected={selectedElement?.id === element.id}
                gridSize={gridSize}
                onSelect={onElementSelect}
                onUpdate={onElementUpdate}
                onDelete={onElementDelete}
              />
            ))}

            {isDraggingOver && dragPosition && ghostElement && (
              <div
                className="absolute pointer-events-none border-2 border-dashed border-primary bg-primary/10 flex items-center justify-center text-xs font-mono text-primary"
                style={{
                  left: `${dragPosition.x}mm`,
                  top: `${dragPosition.y}mm`,
                  width: `${ghostElement.defaultWidth}mm`,
                  height: `${ghostElement.defaultHeight}mm`,
                  opacity: 0.6,
                }}
              >
                <span>{dragPosition.x}mm, {dragPosition.y}mm</span>
              </div>
            )}
          </div>

          {isDraggingOver && dragPosition && (
            <div
              className="fixed pointer-events-none bg-popover text-popover-foreground px-3 py-1.5 rounded-md text-xs font-mono shadow-lg z-50"
              style={{
                left: (dragPosition.x * MM_TO_PX) + (canvasRef.current?.getBoundingClientRect().left || 0) + 16,
                top: (dragPosition.y * MM_TO_PX) + (canvasRef.current?.getBoundingClientRect().top || 0) + 16,
              }}
            >
              {dragPosition.x}mm × {dragPosition.y}mm
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
