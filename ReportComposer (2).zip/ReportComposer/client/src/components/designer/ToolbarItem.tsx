import { ToolbarElement } from "@shared/schema";
import * as LucideIcons from "lucide-react";

interface ToolbarItemProps {
  element: ToolbarElement;
  onDragStart: () => void;
}

export function ToolbarItem({ element, onDragStart }: ToolbarItemProps) {
  const Icon = (LucideIcons as any)[element.icon] || LucideIcons.Square;

  const handleDragStart = (e: React.DragEvent) => {
    e.dataTransfer.effectAllowed = "copy";
    e.dataTransfer.setData("application/json", JSON.stringify(element));
    onDragStart();
  };

  return (
    <div
      draggable
      onDragStart={handleDragStart}
      className="flex flex-col items-center justify-center p-3 rounded-md border-2 border-dashed border-transparent hover:border-primary hover-elevate active-elevate-2 cursor-grab transition-colors"
      data-testid={`toolbar-item-${element.type}`}
    >
      <Icon className="w-6 h-6 mb-2 text-sidebar-foreground" />
      <span className="text-xs text-center text-sidebar-foreground">{element.label}</span>
    </div>
  );
}
