import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useLayouts } from "@/hooks/useLayouts";
import { ReportLayout } from "@shared/schema";
import { Loader2 } from "lucide-react";

interface OpenDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onLoad: (layout: { id: string; name: string; elements: any[] }) => void;
}

export function OpenDialog({ open, onOpenChange, onLoad }: OpenDialogProps) {
  const { data: layouts, isLoading } = useLayouts();

  const handleLoadLayout = (layout: ReportLayout) => {
    onLoad({
      id: layout.id!,
      name: layout.name,
      elements: layout.elements,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]" data-testid="dialog-open">
        <DialogHeader>
          <DialogTitle>Open Layout</DialogTitle>
          <DialogDescription>
            Select a layout to open
          </DialogDescription>
        </DialogHeader>
        <div className="py-4">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
            </div>
          ) : layouts && layouts.length > 0 ? (
            <div className="space-y-2">
              {layouts.map((layout) => (
                <div
                  key={layout.id}
                  className="flex items-center justify-between p-3 rounded-md border border-border hover-elevate active-elevate-2 cursor-pointer"
                  onClick={() => handleLoadLayout(layout)}
                  data-testid={`layout-item-${layout.id}`}
                >
                  <div className="flex-1">
                    <h4 className="font-medium text-sm">{layout.name}</h4>
                    <p className="text-xs text-muted-foreground">
                      {layout.elements.length} element{layout.elements.length !== 1 ? 's' : ''}
                    </p>
                  </div>
                  <Button 
                    size="sm" 
                    variant="ghost"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleLoadLayout(layout);
                    }}
                    data-testid={`button-open-${layout.id}`}
                  >
                    Open
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <p>No saved layouts found</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
