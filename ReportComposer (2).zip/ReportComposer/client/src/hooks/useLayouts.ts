import { useQuery, useMutation } from "@tanstack/react-query";
import { ReportLayout, InsertReportLayout } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";

export function useLayouts() {
  return useQuery<ReportLayout[]>({
    queryKey: ["/api/layouts"],
  });
}

export function useLayout(id: string | undefined) {
  return useQuery<ReportLayout>({
    queryKey: ["/api/layouts", id],
    enabled: !!id,
  });
}

export function useCreateLayout() {
  return useMutation({
    mutationFn: async (data: InsertReportLayout) => {
      return await apiRequest("POST", "/api/layouts", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/layouts"] });
    },
  });
}

export function useUpdateLayout() {
  return useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<ReportLayout> }) => {
      return await apiRequest("PATCH", `/api/layouts/${id}`, updates);
    },
    onSuccess: (_, { id }) => {
      queryClient.invalidateQueries({ queryKey: ["/api/layouts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/layouts", id] });
    },
  });
}

export function useDeleteLayout() {
  return useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/layouts/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/layouts"] });
    },
  });
}
