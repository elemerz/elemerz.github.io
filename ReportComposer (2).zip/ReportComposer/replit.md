# Report Designer - Layout Manager

## Overview
A professional report designer application with a user-friendly Layout Manager interface. **Migrated to Angular 20** with standalone components, separate HTML templates, and LESS stylesheets.

## Purpose
Create and manage report layouts using a drag-and-drop interface with precise positioning, grid snapping, and real-time visual feedback.

## Current State
✅ **Angular 20 Migration Complete** - Full standalone component architecture with LESS styling
✅ **React Version Available** - Original implementation in client/ directory

## Recent Changes (October 2025)
- **October 8, 2025 (PDF-Focused Elements):**
  - **Removed interactive/multimedia elements not suitable for printed PDF reports**
  - Removed: button, input, textarea, checkbox, radio, select (form elements)
  - Removed: video, audio (multimedia elements)
  - Toolbar now shows only PDF-appropriate elements with HTML previews
  - Kept: heading, paragraph, text, div, section, article, image, table, list, link
  - Fixed host element positioning bug (moved styles from inner div to :host)
  - Element drag-drop now works correctly without coordinate offset issues
- **October 8, 2025 (Angular Migration):**
  - **Complete Angular 20 migration with standalone components**
  - Implemented feature-based directory structure (layout/, designer/, shared/, core/)
  - Created separate files for each component: .ts, .html, .less
  - Migrated to LESS theme system from Tailwind CSS
  - Implemented Angular signals for reactive state management
  - Created core services: DesignerStateService, LayoutsApiService, DragDropService
  - Configured HttpClient for Express backend integration
  - Built all UI components: MenuBar, StatusBar, ToolbarPanel, PropertyPanel, Canvas, CanvasElement
  - Implemented SaveDialog and OpenDialog for layout persistence
  - Wired menu actions through AppComponent event handlers
  - Added loadLayout() and clearLayout() methods to DesignerStateService
  - Fixed signal binding patterns for proper two-way data flow
  - Application successfully builds and architect-reviewed
- **October 7, 2025 (Latest):**
  - Increased grid visibility on A4 canvas (opacity from 0.25 to 0.6)
  - Narrowed collapse buttons from 24px to 12px width
  - Repositioned collapse buttons to track split bars dynamically
- **October 7, 2025 (Earlier):**
  - Fixed theme initialization to properly override cached dark mode with light mode
  - Transformed canvas from infinite grid to fixed A4 sheet (210mm × 297mm)
  - Added visible borders and centered A4 sheet with gray workspace background
  - Implemented proper coordinate system with MM_TO_PX conversion (3.7795275591)
  - Fixed element positioning to use consistent mm units throughout the system
- **October 7, 2025 (Earlier):**
  - Switched to light mode (BlackOnWhite) theme as default
  - Property Panel now permanently visible in East zone with empty state when no element selected
  - Added toggle buttons for both West and East zones for better collapsibility control
  - Fixed PropertyPanel JSX structure issues
- **Initial MVP Implementation:**
  - Complete Layout Manager system with border layout
  - Resizable/collapsible regions with drag handles
  - Drag-drop functionality with grid snapping (10mm)
  - Context menus and property panels
  - Undo/redo history management
  - Save/Load functionality with backend persistence
  - Fixed critical event listener bugs in drag-drop system

## Project Architecture

### Angular 20 Frontend (ng-app/)
- **Standalone Components Architecture:**
  - All components use standalone: true with explicit imports
  - No NgModule, uses provideHttpClient in app.config.ts
  - Each component has separate .ts, .html, and .less files
  
- **Directory Structure:**
  ```
  ng-app/src/app/
  ├── core/
  │   └── services/
  │       ├── designer-state.service.ts    # State management with signals
  │       ├── layouts-api.service.ts       # HTTP API integration
  │       └── drag-drop.service.ts         # Drag-drop state
  ├── layout/
  │   ├── menu-bar/                        # North region
  │   ├── status-bar/                      # South region
  │   ├── toolbar-panel/                   # West region
  │   └── property-panel/                  # East region
  ├── designer/
  │   ├── canvas/                          # Center region (A4 sheet)
  │   └── canvas-element/                  # Draggable elements
  ├── shared/
  │   └── models/
  │       └── schema.ts                    # Data models & types
  └── app.ts                               # Root component (border layout)
  ```

- **State Management with Angular Signals:**
  - `DesignerStateService`: Canvas elements, selection, history, undo/redo
  - `DragDropService`: Drag state, ghost preview, grid snapping
  - `LayoutsApiService`: Backend API communication

- **Component Architecture:**
  - `AppComponent`: Border layout shell with resizable panels
  - `MenuBarComponent`: File/Edit menus with dropdowns
  - `StatusBarComponent`: Status messages and cursor coordinates
  - `ToolbarPanelComponent`: Accordion with HTML elements (drag sources)
  - `PropertyPanelComponent`: Element property editor (always visible, empty state)
  - `CanvasComponent`: A4 sheet with grid, drop zone, elements container
  - `CanvasElementComponent`: Individual draggable elements with context menu

- **Styling System (LESS):**
  - Theme variables in `src/styles/theme.less`
  - Material Design 3 / Fluent Design hybrid color palette
  - Converted Tailwind tokens to LESS variables
  - Component-specific styles in separate .less files

- **Key Features:**
  - Angular signals for reactive updates
  - HttpClient for API integration
  - Custom drag-drop with grid snapping (10mm)
  - Context menus for element operations
  - Undo/redo history management
  - MM to PX conversion (3.7795275591) for A4 layout

### React Frontend (client/ - Original)
### Frontend (React + TypeScript)
- **Border Layout System:**
  - North: MenuBar (File, Edit menus)
  - West: Toolbars Panel (accordion-style, collapsible with toggle button)
  - East: Property Panel (always visible, collapsible with toggle button, shows empty state when no element selected)
  - South: StatusBar (messages and cursor coordinates)
  - Center: Canvas (A4 sheet - 210mm × 297mm, centered with visible borders)

- **Key Components:**
  - `Designer` - Main page with layout orchestration
  - `MenuBar` - File/Edit menu operations
  - `ToolbarPanel` - Accordion with categorized HTML elements
  - `Canvas` - Grid-based drop zone with drag preview
  - `CanvasElementComponent` - Draggable, editable elements
  - `PropertyPanel` - Element property editor
  - `StatusBar` - Real-time status and position display
  - `ResizeHandle` - Resizable region dividers
  - `SaveDialog` / `OpenDialog` - Layout persistence dialogs

### Backend (Express + In-Memory Storage)
- RESTful API for layout management
- CRUD operations: GET, POST, PATCH, DELETE
- In-memory storage (MemStorage)
- Type-safe with Zod validation

### Data Model
- **Canvas Elements:** ID, type, x/y position (mm), width/height (mm), content, properties
- **Layouts:** ID, name, elements array, grid settings
- **Element Types (PDF-appropriate only):** Text, Heading, Paragraph, Div, Section, Article, Image, Table, List, Link

## Key Features

### 1. Drag-Drop System
- Drag HTML elements from toolbar to canvas
- Ghost preview during drag with position indicators
- Grid snapping (10mm increments)
- Real-time position display in millimeters
- Elements remain in toolbar after drag (copy behavior)

### 2. Element Management
- Click to select elements
- Drag to reposition on canvas
- Right-click context menu (Properties, Delete)
- Property panel for detailed editing (position, size, content)
- Visual selection indicators with measurements

### 3. Layout Operations
- **New:** Clear canvas and reset
- **Save:** Save current layout (creates new or updates existing)
- **Open:** Load saved layouts from storage
- **Close:** Reset to new layout
- **Undo/Redo:** History-based state management

### 4. UI/UX Features
- Collapsible regions (West and East panels with toggle buttons)
- Resizable panels with drag handles
- Light mode (BlackOnWhite) theme by default
- Property panel with empty state when no element is selected
- Smooth transitions and animations
- Professional design following Material Design principles
- Grid background with subtle lines
- Real-time cursor coordinates in StatusBar

## Technology Stack

### Angular Version (ng-app/)
- **Frontend:** Angular 20, TypeScript, LESS
- **Components:** Standalone architecture (no NgModule)
- **State Management:** Angular signals
- **HTTP Client:** Angular HttpClient
- **Styling:** LESS with theme variables
- **Build:** Angular CLI with esbuild
- **Bundle Size:** 297.67 kB (initial)

### React Version (client/)
- **Frontend:** React, TypeScript, Tailwind CSS, Shadcn UI
- **Backend:** Express.js, Node.js
- **State Management:** React hooks, TanStack Query
- **Styling:** Tailwind CSS with custom design tokens
- **Build:** Vite
- **Type Safety:** TypeScript, Zod schemas

### Backend (Shared)
- **Express.js** on port 3000 (API only) or port 5000 (with Vite)
- **In-memory storage** (MemStorage)
- **RESTful API:** /api/layouts CRUD operations
- **Validation:** Zod schemas

## Design Guidelines
Follows professional design system based on Material Design 3 / Fluent Design hybrid:
- Light mode (BlackOnWhite) primary interface
- Cool blue accent color (217 91% 60%)
- Inter font for UI, JetBrains Mono for coordinates
- Subtle grid background
- Minimal, purposeful interactions
- Focus on workspace maximization

## User Preferences
- Light mode preferred
- Grid size: 10mm
- Minimal visual noise
- Professional productivity tool aesthetic
- Precision positioning with millimeter accuracy

## Development Notes

### Angular Development
- **Setup Angular Dev Server:**
  1. Configure proxy: `ng-app/proxy.conf.json` proxies /api to Express backend
  2. Backend runs on port 3000: `PORT=3000 npm run dev`
  3. Frontend runs on port 5000: `cd ng-app && npm start`
  4. Or use startup script: `./start-angular-dev.sh`

- **Angular-Specific:**
  - Signals for reactive state (no RxJS required for basic state)
  - HostListener decorators for drag events
  - Standalone components with explicit imports
  - LESS theme system with @import for variables

### React Development (Original)
- Uses in-memory storage (data clears on server restart)
- Event listeners properly managed with useEffect
- useCallback used for stable event handlers
- Grid snapping implemented for precise positioning
- History management for undo/redo

### Running Angular App
**Angular runs on port 4200** (React runs on port 5000)

**Option 1: Manual (Recommended for development)**
```bash
# Terminal 1: Start Express backend
PORT=3000 NODE_ENV=development tsx server/index.ts

# Terminal 2: Start Angular frontend
cd ng-app && npm start
```
Access Angular app at: **http://localhost:4200**

**Option 2: Startup Script**
```bash
./start-angular-dev.sh
```
Access Angular app at: **http://localhost:4200**

**Option 3: Run Both Apps Side-by-Side**
- React app (port 5000): Use the "Start application" workflow
- Angular app (port 4200): Run `./start-angular-dev.sh` in terminal

## Future Enhancements (Not in MVP)
- Database persistence (PostgreSQL)
- Element resize handles
- Element rotation
- Multi-select and alignment tools
- Export to PDF/HTML
- Templates and presets
- Collaborative editing
- Advanced property customization
