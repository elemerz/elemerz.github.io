import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Canvas element types
export const elementTypeSchema = z.enum([
  "text",
  "heading",
  "paragraph",
  "button",
  "input",
  "textarea",
  "checkbox",
  "radio",
  "select",
  "div",
  "section",
  "article",
  "image",
  "video",
  "audio",
  "table",
  "list",
  "link"
]);

export type ElementType = z.infer<typeof elementTypeSchema>;

// Canvas element on the grid
export const canvasElementSchema = z.object({
  id: z.string(),
  type: elementTypeSchema,
  x: z.number(), // position in mm
  y: z.number(), // position in mm
  width: z.number().default(100), // size in mm
  height: z.number().default(50), // size in mm
  properties: z.record(z.any()).default({}),
  content: z.string().default(""),
});

export type CanvasElement = z.infer<typeof canvasElementSchema>;

// Layout/Report design
export const reportLayoutSchema = z.object({
  id: z.string().optional(),
  name: z.string(),
  elements: z.array(canvasElementSchema),
  gridSize: z.number().default(10), // grid size in mm
  canvasWidth: z.number().default(297), // A4 width in mm
  canvasHeight: z.number().default(210), // A4 height in mm (landscape)
});

export type ReportLayout = z.infer<typeof reportLayoutSchema>;

export const insertCanvasElementSchema = canvasElementSchema.omit({ id: true });
export type InsertCanvasElement = z.infer<typeof insertCanvasElementSchema>;

export const insertReportLayoutSchema = reportLayoutSchema.omit({ id: true });
export type InsertReportLayout = z.infer<typeof insertReportLayoutSchema>;

// Toolbar element categories
export interface ToolbarElement {
  type: ElementType;
  label: string;
  icon: string;
  defaultWidth: number; // in mm
  defaultHeight: number; // in mm
  category: "text" | "containers" | "form" | "media" | "layout";
}

export const toolbarElements: ToolbarElement[] = [
  // Text Elements
  { type: "heading", label: "Heading", icon: "Heading", defaultWidth: 150, defaultHeight: 30, category: "text" },
  { type: "paragraph", label: "Paragraph", icon: "Text", defaultWidth: 200, defaultHeight: 50, category: "text" },
  { type: "text", label: "Text", icon: "Type", defaultWidth: 100, defaultHeight: 20, category: "text" },
  
  // Container Elements
  { type: "div", label: "Div", icon: "Square", defaultWidth: 150, defaultHeight: 100, category: "containers" },
  { type: "section", label: "Section", icon: "RectangleHorizontal", defaultWidth: 200, defaultHeight: 150, category: "containers" },
  { type: "article", label: "Article", icon: "FileText", defaultWidth: 200, defaultHeight: 200, category: "containers" },
  
  // Form Elements
  { type: "button", label: "Button", icon: "RectangleHorizontal", defaultWidth: 100, defaultHeight: 35, category: "form" },
  { type: "input", label: "Input", icon: "RectangleHorizontal", defaultWidth: 150, defaultHeight: 30, category: "form" },
  { type: "textarea", label: "Textarea", icon: "Square", defaultWidth: 200, defaultHeight: 80, category: "form" },
  { type: "checkbox", label: "Checkbox", icon: "CheckSquare", defaultWidth: 20, defaultHeight: 20, category: "form" },
  { type: "radio", label: "Radio", icon: "Circle", defaultWidth: 20, defaultHeight: 20, category: "form" },
  { type: "select", label: "Select", icon: "ChevronDown", defaultWidth: 150, defaultHeight: 30, category: "form" },
  
  // Media Elements
  { type: "image", label: "Image", icon: "Image", defaultWidth: 100, defaultHeight: 100, category: "media" },
  { type: "video", label: "Video", icon: "Video", defaultWidth: 200, defaultHeight: 150, category: "media" },
  { type: "audio", label: "Audio", icon: "Music", defaultWidth: 200, defaultHeight: 40, category: "media" },
  
  // Layout Elements
  { type: "table", label: "Table", icon: "Table", defaultWidth: 200, defaultHeight: 150, category: "layout" },
  { type: "list", label: "List", icon: "List", defaultWidth: 150, defaultHeight: 100, category: "layout" },
  { type: "link", label: "Link", icon: "Link", defaultWidth: 100, defaultHeight: 20, category: "layout" },
];
