# ReportDesigner Layout Manager - Design Guidelines

## Design Approach

**Selected Approach:** Design System - Material Design 3 / Fluent Design Hybrid

**Rationale:** This is a professional productivity tool requiring clarity, efficiency, and familiarity. Drawing from Material Design's component patterns and Fluent Design's productivity focus creates an interface that feels both modern and purposeful - similar to industry standards like Figma, Adobe XD, and Visual Studio Code.

**Key Design Principles:**
- **Clarity Over Decoration:** Every visual element serves a functional purpose
- **Spatial Efficiency:** Maximize work area while maintaining accessible controls
- **Visual Feedback:** Clear interaction states for drag-drop, resize, and selection operations
- **Professional Neutrality:** Interface recedes to let user's design work take center stage

---

## Core Design Elements

### A. Color Palette

**Dark Mode (Primary Interface):**
- **Surface Colors:** Deep charcoal backgrounds (220 8% 12% for main surfaces, 220 8% 8% for sidebar/panels)
- **Work Area Canvas:** Slightly lighter neutral (220 6% 18%) to differentiate from chrome
- **Grid Lines:** Subtle gray (220 10% 25% at 30% opacity) for minimal visual noise
- **Accent/Primary:** Cool blue (217 91% 60%) for interactive elements, selected states, drag indicators
- **Success/Confirm:** Muted green (142 76% 36%)
- **Warning/Alert:** Amber (38 92% 50%)
- **Text Primary:** High contrast white/off-white (220 9% 95%)
- **Text Secondary:** Medium gray (220 9% 65%)

**Light Mode (Optional Toggle):**
- **Surface Colors:** Clean whites/light grays (220 9% 98% for main, 220 9% 94% for panels)
- **Work Area Canvas:** Pure white (0 0% 100%)
- **Grid Lines:** Light gray (220 10% 80% at 40% opacity)
- **Accent/Primary:** Deeper blue (217 91% 48%)

### B. Typography

**Font Stack:**
- **Primary UI:** Inter (via Google Fonts) - clean, modern, excellent readability at small sizes
- **Monospace/Code:** JetBrains Mono (for coordinate displays, measurements)

**Type Scale:**
- **Menu Bar:** 14px, medium weight (500)
- **Toolbar Labels:** 12px, regular weight (400)
- **Status Bar:** 13px, regular weight
- **Property Panel Headers:** 14px, semibold (600)
- **Property Panel Values:** 13px, regular
- **Canvas Measurements:** 11px, monospace, medium weight

### C. Layout System

**Spacing Primitives:** Tailwind units of 1, 2, 4, 6, 8, 12, 16 (focused on 2, 4, 8 for consistency)
- **Component Padding:** p-2 for tight spacing (toolbar items), p-4 for comfortable (panels)
- **Section Gaps:** gap-2 for related items, gap-4 for distinct groups
- **Region Margins:** Minimal - focus on maximizing work area

**Border Layout Specifications:**
- **North (MenuBar):** Fixed height h-10, spans full width
- **West (Toolbars):** Default width w-64, collapsible to w-0, min-width when expanded: 200px, max-width: 400px
- **South (StatusBar):** Fixed height h-8, spans full width
- **East (Properties):** Default width w-80, collapsible, appears when element selected
- **Center (WorkArea):** Fills remaining space, scrollable overflow

**Resize Handles:**
- 4px wide invisible hit area, 1px visible divider line
- Hover state: Accent color glow, cursor changes to col-resize/row-resize
- Active drag: Accent color solid line with slight shadow

### D. Component Library

**1. MenuBar (North Region)**
- Dark background with subtle bottom border (1px, 220 10% 20%)
- Menu items: horizontal layout, px-4 py-2, hover: lighter background (220 8% 18%)
- Dropdown menus: 12px below parent, w-48, rounded corners (rounded-md), shadow-lg
- Menu item hover: accent background at 10% opacity

**2. Toolbar Zone (West Region - Accordion)**
- **Accordion Headers:** Full width, py-3 px-4, semibold text, chevron icon (rotates on expand)
- **Accordion Content:** Collapsed: h-0, Expanded: auto height with smooth transition
- **Toolbar Items:** Grid layout (grid-cols-2), gap-2, each item:
  - 80px x 80px touch target
  - Icon centered above label
  - Rounded border (rounded-lg border-2 border-dashed border-transparent)
  - Hover: border becomes accent color, background lightens slightly

**3. Work Area Canvas**
- **Grid Pattern:** SVG background, 10mm squares for standard grid
- **Grid Styling:** Thin lines (0.5px), low opacity (25%), zoom-responsive
- **Zoom Levels:** 25%, 50%, 75%, 100%, 150%, 200%
- **Canvas Controls:** Bottom-right floating panel with zoom slider and fit-to-screen button

**4. Drag-Drop Visuals**
- **Ghost Element:** 60% opacity version of original, follows cursor with 12px offset
- **Position Indicator:** Floating tooltip showing X/Y coordinates in mm, positioned 16px below cursor
- **Snap Feedback:** Element outline pulses briefly when snapping to grid
- **Drop Zone Hover:** Canvas region highlights with accent color border (2px dashed) when draggable enters

**5. Placed Elements on Canvas**
- **Default State:** 1px solid border (accent color at 40% opacity)
- **Hover State:** Border brightens to 80% opacity, resize handles appear at corners
- **Selected State:** Accent color solid border (2px), corner/edge resize handles visible
- **Right-Click Menu:** Appears at cursor position, w-48, rounded-lg, shadow-xl
  - Menu items: py-2 px-4, hover: accent background

**6. Floating Property Panel**
- **Appearance:** Draggable window, w-80, rounded-lg, shadow-2xl
- **Header:** Gradient background (subtle), h-12, includes title and close button
- **Content:** Scrollable, organized in sections with labeled inputs
- **Input Fields:** Full width, rounded borders, focus: accent color ring

**7. StatusBar (South Region)**
- Darker background than main surface (220 8% 8%)
- Text: secondary color, left-aligned with px-4
- Right section: shows canvas zoom level and cursor coordinates

**8. Collapsible Controls**
- Toggle buttons in region corners (16px x 16px)
- Icon-only (chevron or arrow), hover: accent color
- Smooth collapse animation (300ms ease-in-out)

### E. Interactions & Animations

**Use Sparingly - Purposeful Only:**
- **Region Collapse/Expand:** 250ms ease-in-out width/height transition
- **Accordion:** 200ms ease transform for chevron rotation, 250ms height transition
- **Drag Ghost:** Appears with 150ms fade-in, position updates with transform (no transition for smooth tracking)
- **Context Menu:** 100ms fade + scale-in from cursor position
- **Resize Handles:** Appear with 150ms fade when element hovered
- **Status Updates:** 200ms fade for text changes

**NO Animations For:**
- Split pane dragging (direct manipulation, no delay)
- Grid scrolling
- Zoom operations
- Property value changes

---

## Interaction Patterns

**Drag-Drop Flow:**
1. User clicks toolbar item → Item gets subtle scale effect (scale-95)
2. Drag starts → Ghost element appears, cursor shows "grabbing"
3. During drag → Position tooltip follows, grid highlights drop zones
4. On snap → Brief pulse animation on ghost outline
5. On drop → Ghost transforms to solid element with 200ms fade-in

**Region Resize:**
- Hover over divider → Cursor changes, divider highlights
- Click-drag → Divider becomes accent colored line, regions resize in real-time
- Release → Divider returns to subtle state

**Context Menu:**
- Right-click element → Menu appears at cursor with 100ms scale-up
- Click outside → Closes with 100ms fade-out
- Hover items → Background color transition (150ms)

---

## Visual Hierarchy Rules

1. **Work Area is King:** Lightest/most prominent surface, draws eye immediately
2. **Chrome Recedes:** Toolbars and panels use darker tones, stay in background
3. **Interactive Elements Pop:** Accent color exclusively for actionable items
4. **Typography Scale:** Larger text for important actions (menu items), smaller for metadata (coordinates)
5. **Depth Through Shadow:** Work area elements cast shadows, chrome elements don't

---

## Accessibility & Usability

- **Contrast Ratios:** Minimum 4.5:1 for all text, 3:1 for interactive elements
- **Focus Indicators:** 2px accent color ring on keyboard focus, offset by 2px
- **Touch Targets:** Minimum 40px x 40px for all interactive elements
- **Keyboard Shortcuts:** Display in menu items, StatusBar shows active shortcuts
- **Color Independence:** Never rely on color alone - use icons, labels, and patterns